/* ============================================================
   Call Intelligence — app.js  (No-API version)
   Uses: Web Speech API (SpeechRecognition) for transcription
         Local NLP algorithms for summarisation
   ============================================================ */

'use strict';

// ── State ──────────────────────────────────────────────────
let currentTab     = 'record';
let isRecording    = false;
let recognition    = null;
let timerInterval  = null;
let seconds        = 0;
let fullTranscript = '';   // accumulated from speech recognition
let interimText    = '';   // current interim result

// ── Browser check ──────────────────────────────────────────
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

// ── Tab switch ─────────────────────────────────────────────
function switchTab(tab, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('tab-' + tab).classList.add('active');
  currentTab = tab;
}

// ── Recording ──────────────────────────────────────────────
function toggleRecord() {
  if (!SpeechRecognition) {
    alert('Your browser does not support the Web Speech API.\nPlease use Chrome or Edge, or use the "Paste Text" tab.');
    return;
  }

  if (!isRecording) {
    startRecording();
  } else {
    stopRecording();
  }
}

function startRecording() {
  fullTranscript = '';
  interimText    = '';

  recognition = new SpeechRecognition();
  recognition.continuous      = true;
  recognition.interimResults  = true;
  recognition.lang            = 'en-US';
  recognition.maxAlternatives = 1;

  recognition.onresult = (event) => {
    let interim = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const t = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        fullTranscript += t + ' ';
      } else {
        interim += t;
      }
    }
    interimText = interim;
    updateLiveText();
  };

  recognition.onerror = (e) => {
    if (e.error === 'not-allowed') {
      alert('Microphone access denied. Please allow microphone permissions.');
      stopRecording();
    }
  };

  recognition.onend = () => {
    // Auto-restart if still in recording mode (handles browser timeout)
    if (isRecording) recognition.start();
  };

  recognition.start();
  isRecording = true;

  // UI
  document.getElementById('recBtn').classList.add('recording');
  document.getElementById('waveform').classList.add('active');
  document.getElementById('recStatus').textContent = '● Listening...';
  document.getElementById('recStatus').classList.add('live');
  document.getElementById('liveBox').style.display = 'block';

  seconds = 0;
  timerInterval = setInterval(() => {
    seconds++;
    const m = String(Math.floor(seconds / 60)).padStart(2, '0');
    const s = String(seconds % 60).padStart(2, '0');
    document.getElementById('timer').textContent = `${m}:${s}`;
  }, 1000);
}

function stopRecording() {
  isRecording = false;
  if (recognition) { recognition.onend = null; recognition.stop(); }
  clearInterval(timerInterval);

  document.getElementById('recBtn').classList.remove('recording');
  document.getElementById('waveform').classList.remove('active');
  document.getElementById('recStatus').textContent = 'Recording stopped — ready to analyse';
  document.getElementById('recStatus').classList.remove('live');
  updateLiveText();
}

function updateLiveText() {
  const el = document.getElementById('liveText');
  el.textContent = (fullTranscript + interimText).trim() || '(Listening for speech...)';
}

// ── Analyse ────────────────────────────────────────────────
function analyseCall() {
  let text = '';

  if (currentTab === 'record') {
    text = fullTranscript.trim();
    if (!text) { alert('No speech detected yet. Start recording first, speak, then stop.'); return; }
  } else {
    text = document.getElementById('textInput').value.trim();
    if (!text) { alert('Please paste a transcript first.'); return; }
  }

  const analysis = analyseText(text);
  showResults(text, analysis);
}

// ── NLP Engine ─────────────────────────────────────────────
const STOP_WORDS = new Set([
  'i','me','my','we','our','you','your','he','she','it','they','them',
  'the','a','an','and','or','but','in','on','at','to','for','of','with',
  'is','was','are','were','be','been','being','have','has','had','do',
  'does','did','will','would','could','should','may','might','shall',
  'that','this','these','those','which','who','what','when','where','how',
  'not','no','so','if','as','by','from','up','out','about','into','just',
  'can','also','its','their','there','than','then','very','more','some',
  'all','any','each','both','few','other','such','same','own','too','now',
  'here','only','over','after','before','again','further','during','while'
]);

const ACTION_KEYWORDS = [
  'will','shall','going to','need to','should','must','have to',
  'plan to','intend to','decided to','agreed to','committed to',
  'follow up','follow-up','schedule','send','share','review','update',
  'complete','finish','implement','create','build','draft','prepare',
  'arrange','confirm','check','discuss','coordinate','reach out','contact'
];

const SENTIMENT_POS = [
  'great','good','excellent','perfect','wonderful','amazing','fantastic',
  'happy','pleased','agree','positive','success','successful','achieved',
  'accomplish','approved','confirm','definitely','absolutely','love',
  'appreciate','thank','thanks','helpful','useful','productive','benefit',
  'opportunity','exciting','excited','confident','confident','clear','resolved'
];

const SENTIMENT_NEG = [
  'bad','poor','terrible','awful','wrong','fail','failed','failure',
  'problem','issue','concern','worried','worried','difficult','hard',
  'challenge','unable','cannot','can\'t','won\'t','delayed','delayed',
  'behind','missed','miss','reject','rejected','disagree','no','not',
  'never','unfortunately','sorry','apology','risk','block','blocker',
  'stuck','unclear','confusing','confused','frustrated','frustrating'
];

function analyseText(text) {
  const sentences  = tokeniseSentences(text);
  const words      = tokeniseWords(text);
  const wordFreq   = buildWordFreq(words);
  const keyPoints  = extractKeyPoints(sentences, wordFreq);
  const actionItems= extractActionItems(sentences);
  const sentiment  = computeSentiment(words);
  const topics     = extractTopics(wordFreq);
  const stats      = computeStats(text, sentences, words);

  return { keyPoints, actionItems, sentiment, topics, stats };
}

function tokeniseSentences(text) {
  return text
    .replace(/\n+/g, ' ')
    .split(/(?<=[.!?])\s+/)
    .map(s => s.trim())
    .filter(s => s.length > 15);
}

function tokeniseWords(text) {
  return text.toLowerCase().match(/\b[a-z']{2,}\b/g) || [];
}

function buildWordFreq(words) {
  const freq = {};
  for (const w of words) {
    if (!STOP_WORDS.has(w)) freq[w] = (freq[w] || 0) + 1;
  }
  return freq;
}

function scoreSentence(sentence, wordFreq) {
  const words = tokeniseWords(sentence);
  if (!words.length) return 0;
  const contentWords = words.filter(w => !STOP_WORDS.has(w));
  if (!contentWords.length) return 0;
  const score = contentWords.reduce((sum, w) => sum + (wordFreq[w] || 0), 0);
  return score / contentWords.length;
}

function extractKeyPoints(sentences, wordFreq) {
  if (!sentences.length) return ['No sufficient content detected.'];

  const scored = sentences.map((s, i) => ({
    text: s,
    score: scoreSentence(s, wordFreq),
    index: i
  }));

  // Sort by score, take top 5, re-sort by original order for readability
  const top = scored
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .sort((a, b) => a.index - b.index)
    .map(s => s.text);

  return top.length ? top : [sentences[0]];
}

function extractActionItems(sentences) {
  const items = [];
  const actionRx = new RegExp(ACTION_KEYWORDS.join('|'), 'i');

  for (const s of sentences) {
    if (actionRx.test(s) && s.length < 200) {
      // Clean up and capitalise
      const clean = s.trim().replace(/^[^A-Za-z]+/, '');
      if (clean.length > 10) items.push(clean);
      if (items.length >= 5) break;
    }
  }

  return items.length ? items : ['No explicit action items detected.'];
}

function computeSentiment(words) {
  let pos = 0, neg = 0;
  for (const w of words) {
    if (SENTIMENT_POS.includes(w)) pos++;
    if (SENTIMENT_NEG.includes(w)) neg++;
  }
  const total = pos + neg || 1;
  const score = Math.round((pos / total) * 100);
  const label = score >= 60 ? 'positive' : score <= 40 ? 'negative' : 'neutral';
  return { label, score };
}

function extractTopics(wordFreq) {
  return Object.entries(wordFreq)
    .filter(([w]) => w.length > 4)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([w]) => w.charAt(0).toUpperCase() + w.slice(1));
}

function computeStats(text, sentences, words) {
  const mins  = Math.ceil(words.length / 130); // avg speaking pace
  const wpm   = words.length;
  return {
    wordCount     : wpm,
    sentenceCount : sentences.length,
    duration      : mins < 1 ? '< 1 min' : `~${mins} min`,
    readTime      : Math.ceil(words.length / 200) + ' min read'
  };
}

// ── Render Results ─────────────────────────────────────────
function showResults(transcript, analysis) {
  const { keyPoints, actionItems, sentiment, topics, stats } = analysis;

  // Transcript
  document.getElementById('transcriptBox').textContent = transcript;

  const sentColor = sentiment.label === 'positive' ? 'var(--success)'
                  : sentiment.label === 'negative' ? 'var(--accent2)'
                  : 'var(--accent3)';

  // Stats row
  const statsHtml = `
    <div class="stat-row">
      <div class="stat-chip"><strong>${stats.wordCount}</strong>Words</div>
      <div class="stat-chip"><strong>${stats.sentenceCount}</strong>Sentences</div>
      <div class="stat-chip"><strong>${stats.duration}</strong>Est. Duration</div>
      <div class="stat-chip"><strong>${stats.readTime}</strong>Read Time</div>
    </div>`;

  // Key points
  const kpHtml = keyPoints.map((kp, i) => `
    <div class="key-point">
      <span class="kp-num">${String(i + 1).padStart(2, '0')}</span>
      <span>${kp}</span>
    </div>`).join('');

  // Action items
  const aiHtml = actionItems.map(ai => `
    <div class="action-item">
      <span class="ai-check">✓</span>
      <span>${ai}</span>
    </div>`).join('');

  // Topics
  const topicsHtml = topics.map(t => `<span class="topic-tag">${t}</span>`).join('');

  document.getElementById('summaryGrid').innerHTML = `
    ${statsHtml}

    <div class="summary-chip full">
      <div class="chip-label">
        <span class="chip-dot" style="background:var(--accent)"></span>
        <span style="color:var(--accent)">Key Points</span>
      </div>
      <div class="chip-content">${kpHtml}</div>
    </div>

    <div class="summary-chip">
      <div class="chip-label">
        <span class="chip-dot" style="background:var(--success)"></span>
        <span style="color:var(--success)">Action Items</span>
      </div>
      <div class="chip-content">${aiHtml}</div>
    </div>

    <div class="summary-chip">
      <div class="chip-label">
        <span class="chip-dot" style="background:${sentColor}"></span>
        <span style="color:${sentColor}">Sentiment · ${sentiment.label}</span>
      </div>
      <div class="chip-content">
        <div style="color:var(--text-dim);font-size:12px">Score: ${sentiment.score}% positive</div>
        <div class="sentiment-bar">
          <div class="sentiment-fill" style="width:${sentiment.score}%;background:${sentColor}"></div>
        </div>
      </div>
    </div>

    <div class="summary-chip full">
      <div class="chip-label">
        <span class="chip-dot" style="background:var(--accent2)"></span>
        <span style="color:var(--accent2)">Key Topics</span>
      </div>
      <div class="chip-content">${topicsHtml}</div>
    </div>
  `;

  document.getElementById('inputCard').style.display = 'none';
  document.getElementById('results').classList.add('show');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ── Copy helpers ───────────────────────────────────────────
function copyEl(id) {
  navigator.clipboard.writeText(document.getElementById(id).textContent).then(() => {
    const btn = event.target;
    const orig = btn.textContent;
    btn.textContent = '✓ Copied!';
    setTimeout(() => btn.textContent = orig, 2000);
  });
}

function copySummary() {
  navigator.clipboard.writeText(document.getElementById('summaryGrid').innerText).then(() => {
    const btn = event.target;
    const orig = btn.textContent;
    btn.textContent = '✓ Copied!';
    setTimeout(() => btn.textContent = orig, 2000);
  });
}

// ── Reset ──────────────────────────────────────────────────
function resetApp() {
  if (isRecording) stopRecording();
  document.getElementById('inputCard').style.display = 'block';
  document.getElementById('results').classList.remove('show');
  document.getElementById('textInput').value = '';
  document.getElementById('liveBox').style.display = 'none';
  document.getElementById('liveText').textContent  = '';
  document.getElementById('recStatus').textContent  = 'Click to start recording';
  document.getElementById('timer').textContent      = '00:00';
  fullTranscript = '';
  seconds = 0;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
