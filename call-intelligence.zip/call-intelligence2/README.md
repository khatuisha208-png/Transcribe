# 📞 Call Intelligence — No API Required

> Transcribe calls live and summarise key points — **100% in your browser**. No API key, no backend, no cost.

## ✨ Features

- **🎙 Live Transcription** — uses the browser's built-in Web Speech API (no external service)
- **✎ Paste Transcript** — analyse existing text from Zoom, Teams, Meet, Otter.ai, etc.
- **🎯 Key Points** — top sentences extracted using TF-IDF-style scoring
- **✅ Action Items** — sentences with action intent automatically detected
- **😊 Sentiment Analysis** — positive / neutral / negative scoring
- **🏷 Topic Tags** — most frequent meaningful terms surfaced
- **📊 Call Stats** — word count, sentence count, estimated duration & read time
- **📋 One-click Copy** — copy transcript or full summary

## 🚀 Quick Start

### Option A — Open directly (simplest)

```bash
git clone https://github.com/YOUR_USERNAME/call-intelligence.git
cd call-intelligence
open index.html     # macOS
# or double-click index.html in Windows/Linux
```

> ⚠️ Some browsers block microphone access for `file://` URLs. Use Option B for recording.

### Option B — Serve locally (recommended for recording)

```bash
# Node.js
npx serve .

# Python 3
python3 -m http.server 8080

# Then open: http://localhost:8080
```

### Option C — GitHub Pages (free hosting)

1. Push this repo to GitHub
2. **Settings → Pages → Source:** `main` branch, `/ (root)`
3. Live at `https://YOUR_USERNAME.github.io/call-intelligence`

---

## 📁 Project Structure

```
call-intelligence/
├── index.html          # App shell
├── css/
│   └── style.css       # All styles
├── js/
│   └── app.js          # Transcription + NLP logic
└── README.md
```

---

## 🧠 How It Works

### Transcription
Uses the **Web Speech API** (`SpeechRecognition`) built into Chrome/Edge. No audio is sent to any server — recognition happens locally in the browser.

### Summarisation (pure JS, no AI)
| Feature | Method |
|---|---|
| Key Points | TF-IDF style sentence scoring — sentences with the highest density of frequent non-stopword terms |
| Action Items | Regex matching on action-intent keywords (will, need to, follow up, schedule, etc.) |
| Sentiment | Positive/negative word lexicon scoring |
| Topics | Top-N most frequent content words (length > 4 chars) |
| Stats | Word count, sentence tokenisation, estimated speaking pace (130 wpm) |

---

## 🌐 Browser Support

| Browser | Live Recording | Paste Text |
|---|---|---|
| Chrome | ✅ | ✅ |
| Edge | ✅ | ✅ |
| Firefox | ❌ (no Web Speech API) | ✅ |
| Safari | ⚠️ Partial | ✅ |

---

## 🔒 Privacy

- **Zero data leaves your device** during live recording — Web Speech API processes audio locally
- No analytics, no cookies, no tracking
- No API keys, no accounts required

---

## 📄 License

MIT — free to use, modify, and distribute.
